# T6UnitedConsole
A ubiquitous external console for T6.

![Main Screen](http://i.imgur.com/So7VD6C.png "T6 United Console Interface")

Supports:
+ t6mp
+ t6zm
+ t6mpv43
+ t6zmv41
